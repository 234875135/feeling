#pragma once

#include <Windows.h>

#include "driver/driver.h"

namespace util
{
    struct roblox_window_state
    {
        DWORD pid = 0;
        HWND hwnd = nullptr;
        LONG bestArea = 0;
    };

    inline BOOL CALLBACK enum_roblox_windows(HWND hwnd, LPARAM lParam)
    {
        auto* state = reinterpret_cast<roblox_window_state*>(lParam);
        if (!state || !hwnd || !IsWindow(hwnd))
            return TRUE;

        DWORD windowPid = 0;
        GetWindowThreadProcessId(hwnd, &windowPid);
        if (!windowPid || windowPid != state->pid)
            return TRUE;

        if (GetWindow(hwnd, GW_OWNER) != nullptr)
            return TRUE;

        if (!IsWindowVisible(hwnd))
            return TRUE;

        RECT rect{};
        if (!GetClientRect(hwnd, &rect))
            return TRUE;

        const LONG width = rect.right - rect.left;
        const LONG height = rect.bottom - rect.top;
        const LONG area = width * height;
        if (width < 200 || height < 200 || area <= state->bestArea)
            return TRUE;

        LONG exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
        if (exStyle & WS_EX_TOOLWINDOW)
            return TRUE;

        state->bestArea = area;
        state->hwnd = hwnd;
        return TRUE;
    }

    inline HWND roblox_window()
    {
        static HWND cached = nullptr;
        const DWORD targetPid = static_cast<DWORD>(drive->processid());

        HWND fg = GetForegroundWindow();
        if (fg && targetPid != 0)
        {
            DWORD fgPid = 0;
            GetWindowThreadProcessId(fg, &fgPid);
            if (fgPid == targetPid)
            {
                cached = fg;
                return cached;
            }
        }

        if (cached && IsWindow(cached))
        {
            DWORD cachedPid = 0;
            GetWindowThreadProcessId(cached, &cachedPid);
            if (cachedPid == targetPid && targetPid != 0)
                return cached;
        }
        cached = nullptr;

        roblox_window_state state{};
        state.pid = targetPid;
        if (state.pid)
            EnumWindows(enum_roblox_windows, reinterpret_cast<LPARAM>(&state));

        if (state.hwnd && IsWindow(state.hwnd))
        {
            cached = state.hwnd;
            return cached;
        }

        cached = FindWindowA(nullptr, "Roblox");
        return cached;
    }

    inline bool roblox_focused()
    {
        HWND fg = GetForegroundWindow();
        if (!fg)
            return false;

        DWORD fgPid = 0;
        GetWindowThreadProcessId(fg, &fgPid);
        const DWORD targetPid = static_cast<DWORD>(drive->processid());
        return fgPid != 0 && targetPid != 0 && fgPid == targetPid;
    }

    inline HWND roblox_input_window()
    {
        HWND fg = GetForegroundWindow();
        if (fg && roblox_focused())
            return fg;
        return roblox_window();
    }
}
