#include "feature/wallcheck.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <mutex>
#include <shared_mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "global.h"

namespace wallcheck
{
    struct part_entry
    {
        std::uintptr_t Parent = 0;
        sdk::vector3 Position{};
        sdk::matrix3 Rotation{};
        sdk::vector3 Size{};
        float BroadRadiusSq = 0.f;
    };

    struct visibility_key
    {
        std::int32_t Ox = 0;
        std::int32_t Oy = 0;
        std::int32_t Oz = 0;
        std::int32_t Tx = 0;
        std::int32_t Ty = 0;
        std::int32_t Tz = 0;
        std::uint32_t Revision = 0;

        bool operator==(const visibility_key& other) const
        {
            return Ox == other.Ox && Oy == other.Oy && Oz == other.Oz &&
                Tx == other.Tx && Ty == other.Ty && Tz == other.Tz &&
                Revision == other.Revision;
        }
    };

    struct visibility_hash
    {
        std::size_t operator()(const visibility_key& key) const
        {
            std::size_t h = 1469598103934665603ull;
            auto mix = [&](std::uint64_t value)
                {
                    h ^= value;
                    h *= 1099511628211ull;
                };

            mix(static_cast<std::uint32_t>(key.Ox));
            mix(static_cast<std::uint32_t>(key.Oy));
            mix(static_cast<std::uint32_t>(key.Oz));
            mix(static_cast<std::uint32_t>(key.Tx));
            mix(static_cast<std::uint32_t>(key.Ty));
            mix(static_cast<std::uint32_t>(key.Tz));
            mix(key.Revision);
            return h;
        }
    };

    struct visibility_entry
    {
        bool Visible = false;
        std::chrono::steady_clock::time_point Expiry{};
    };

    static std::vector<part_entry> part_cache;
    static std::shared_mutex cache_mutex;
    static std::atomic<std::uint32_t> cache_revision{ 1u };

    static std::unordered_map<visibility_key, visibility_entry, visibility_hash> visibility_cache;
    static std::mutex visibility_mutex;
    static std::atomic<std::uint32_t> visibility_write_counter{ 0u };

    bool valid(const sdk::vector3& v)
    {
        return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z);
    }

    static bool is_world_part(const std::string& kind)
    {
        return kind == "Part" || kind == "MeshPart" || kind == "WedgePart" ||
            kind == "CornerWedgePart" || kind == "TrussPart" || kind == "UnionOperation";
    }

    static void get_parts(const sdk::instance& parent, std::vector<part_entry>& parts, int depth = 0)
    {
        if (!parent.Address || depth > 64)
            return;

        for (const sdk::instance& child : parent.children())
        {
            if (!child.Address)
                continue;

            const std::string kind = child.kind();
            if (kind == "Model" && child.childclass("Humanoid").Address)
                continue;

            if (is_world_part(kind))
            {
                sdk::part part(child.Address);
                if (part.transparency() <= 0.95f)
                {
                    sdk::part primitive = part.primitive();
                    if (primitive.Address)
                    {
                        const sdk::vector3 pos = primitive.position();
                        const sdk::vector3 size = primitive.size();
                        if (valid(pos) && valid(size) && (size.x > 0.f || size.y > 0.f || size.z > 0.f))
                        {
                            const float half_diag = 0.5f * std::sqrt(size.x * size.x + size.y * size.y + size.z * size.z);
                            const float broad_radius = half_diag + 0.55f;

                            part_entry entry{};
                            entry.Parent = part.parent().Address;
                            entry.Position = pos;
                            entry.Rotation = primitive.rotation();
                            entry.Size = size;
                            entry.BroadRadiusSq = broad_radius * broad_radius;
                            parts.push_back(entry);
                        }
                    }
                }
            }

            get_parts(child, parts, depth + 1);
        }
    }

    void update_cache()
    {
        if (!global::workspace.Address)
            return;

        std::vector<part_entry> next;
        next.reserve(2048);
        get_parts(global::workspace, next);

        {
            std::unique_lock<std::shared_mutex> lock(cache_mutex);
            part_cache = std::move(next);
            cache_revision.fetch_add(1u, std::memory_order_relaxed);
        }

        std::lock_guard<std::mutex> lock(visibility_mutex);
        visibility_cache.clear();
    }

    static bool intersects_obb(
        const sdk::vector3& ray_origin,
        const sdk::vector3& ray_dir,
        const sdk::vector3& part_pos,
        const sdk::matrix3& part_rot,
        const sdk::vector3& part_size,
        float& distance)
    {
        const sdk::vector3 relative = ray_origin - part_pos;

        const sdk::vector3 local_origin{
            relative.x * part_rot.data[0] + relative.y * part_rot.data[3] + relative.z * part_rot.data[6],
            relative.x * part_rot.data[1] + relative.y * part_rot.data[4] + relative.z * part_rot.data[7],
            relative.x * part_rot.data[2] + relative.y * part_rot.data[5] + relative.z * part_rot.data[8]
        };

        const sdk::vector3 local_dir{
            ray_dir.x * part_rot.data[0] + ray_dir.y * part_rot.data[3] + ray_dir.z * part_rot.data[6],
            ray_dir.x * part_rot.data[1] + ray_dir.y * part_rot.data[4] + ray_dir.z * part_rot.data[7],
            ray_dir.x * part_rot.data[2] + ray_dir.y * part_rot.data[5] + ray_dir.z * part_rot.data[8]
        };

        const sdk::vector3 half = part_size * 0.5f;
        float t_min = -1e30f;
        float t_max = 1e30f;

        auto slab = [&](float origin, float dir, float half_size) -> bool
            {
                if (std::abs(dir) > 1e-6f)
                {
                    const float t1 = (-half_size - origin) / dir;
                    const float t2 = (half_size - origin) / dir;
                    t_min = (std::max)(t_min, (std::min)(t1, t2));
                    t_max = (std::min)(t_max, (std::max)(t1, t2));
                    return true;
                }

                return std::abs(origin) <= half_size;
            };

        if (!slab(local_origin.x, local_dir.x, half.x)) return false;
        if (!slab(local_origin.y, local_dir.y, half.y)) return false;
        if (!slab(local_origin.z, local_dir.z, half.z)) return false;
        if (t_max < 0.f || t_min > t_max) return false;

        distance = t_min;
        return true;
    }

    static inline float dot3(const sdk::vector3& a, const sdk::vector3& b)
    {
        return a.x * b.x + a.y * b.y + a.z * b.z;
    }

    static std::int32_t quantize(float v)
    {
        constexpr float inv_step = 5.0f; // 0.2 world units
        return static_cast<std::int32_t>(std::lround(v * inv_step));
    }

    static visibility_key make_key(const sdk::vector3& origin, const sdk::vector3& target)
    {
        visibility_key key{};
        key.Ox = quantize(origin.x);
        key.Oy = quantize(origin.y);
        key.Oz = quantize(origin.z);
        key.Tx = quantize(target.x);
        key.Ty = quantize(target.y);
        key.Tz = quantize(target.z);
        key.Revision = cache_revision.load(std::memory_order_relaxed);
        return key;
    }

    static bool read_visibility_cache(const visibility_key& key, bool& visible)
    {
        const auto now = std::chrono::steady_clock::now();
        std::lock_guard<std::mutex> lock(visibility_mutex);
        auto it = visibility_cache.find(key);
        if (it == visibility_cache.end())
            return false;

        if (it->second.Expiry <= now)
        {
            visibility_cache.erase(it);
            return false;
        }

        visible = it->second.Visible;
        return true;
    }

    static void write_visibility_cache(const visibility_key& key, bool visible)
    {
        const auto now = std::chrono::steady_clock::now();
        const auto ttl = std::chrono::milliseconds(visible ? 18 : 10);

        std::lock_guard<std::mutex> lock(visibility_mutex);
        visibility_cache[key] = visibility_entry{ visible, now + ttl };

        constexpr std::size_t max_entries = 8192;
        const std::uint32_t writes = visibility_write_counter.fetch_add(1u, std::memory_order_relaxed) + 1u;
        if ((writes % 256u) != 0u && visibility_cache.size() <= max_entries)
            return;

        for (auto it = visibility_cache.begin(); it != visibility_cache.end();)
        {
            if (it->second.Expiry <= now)
                it = visibility_cache.erase(it);
            else
                ++it;
        }

        if (visibility_cache.size() > max_entries)
        {
            const std::size_t target_size = max_entries / 2;
            auto it = visibility_cache.begin();
            while (visibility_cache.size() > target_size && it != visibility_cache.end())
                it = visibility_cache.erase(it);
        }
    }

    bool can_see(const sdk::vector3& origin, const sdk::vector3& target)
    {
        if (!valid(origin) || !valid(target))
            return false;

        const visibility_key key = make_key(origin, target);
        bool cached_visible = false;
        if (read_visibility_cache(key, cached_visible))
            return cached_visible;

        const sdk::vector3 delta = target - origin;
        const float target_dist = delta.magnitude();
        if (target_dist < 0.1f)
            return true;

        const sdk::vector3 dir = delta / target_dist;
        const std::uintptr_t local_char = global::LocalPlayer.character.Address;

        std::shared_lock<std::shared_mutex> lock(cache_mutex);
        for (const part_entry& entry : part_cache)
        {
            if (local_char && entry.Parent == local_char)
                continue;

            // Broad-phase culling:
            // 1) part center projection must be on the segment [origin, target]
            // 2) ray-to-center perpendicular distance must be within part bounding sphere
            const sdk::vector3 to_part = entry.Position - origin;
            const float along = dot3(to_part, dir);
            if (along <= 0.01f || along >= target_dist - 0.01f)
                continue;

            const float center_dist_sq = dot3(to_part, to_part);
            const float perp_sq = center_dist_sq - along * along;
            if (perp_sq > entry.BroadRadiusSq)
                continue;

            float hit_dist = 0.f;
            if (intersects_obb(origin, dir, entry.Position, entry.Rotation, entry.Size, hit_dist) &&
                hit_dist > 0.01f && hit_dist < target_dist - 0.5f)
            {
                lock.unlock();
                write_visibility_cache(key, false);
                return false;
            }
        }

        lock.unlock();
        write_visibility_cache(key, true);
        return true;
    }
}
